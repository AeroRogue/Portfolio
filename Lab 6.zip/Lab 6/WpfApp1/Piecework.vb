﻿''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'Author: Cameron Krueger                               '
'Last Modified Date: October 14, 2017                               '
'Descritpion: All of the calculations and most         '
'             validation happens here.  A class        ' 
'             method called CalculationPay Is dedicated' 
'             to doing the calculation for the worker  '
'             pay, average pay, And total amount Of    '
'             workers.  All of the validation happens  '
'             in the property procedures underneath    '
'             the Class methods and if the data is     '
'             validated it moves that data To the Class' 
'             methods. Then It can output the data.    '
'             Finally it sets up an event that gets    '
'             handled and exicuted in the form code.   '
''''''''''''''''''''''''''''''''''''''''''''''''''''''''
'Option Strict On
Imports System.Data
Imports System.Data.SqlClient

Friend Class Piecework

#Region "Class Events"

    Protected Friend Event PromotionEarned(ByVal pieceworkInstance As Piecework)

#End Region

#Region "Instance and Shared Property Variables"

    'Private Variable Declerations
    Protected WorkerName As String
    Protected MessagesSent As Integer
    Protected WorkerPay As Decimal

    Protected IsValid As Boolean = True

    'Private Shared Variable Declerations
    Protected Shared TotalCalculatedPay As Double
    Protected Shared TotalEmployeesProcessed As Integer
    Protected Shared TotalMessagesSent As Integer
    Protected Shared AverageCalcualtedPay As Double
    Protected Const BonusPayOne As Decimal = 20
    Protected Const BonusPayTwo As Decimal = 30

#End Region

#Region "Constructors"

    'Paramaterized Constructor
    Friend Sub New(ByVal workerName As String, ByVal messagesSent As String)
        Me.Name = workerName
        Me.Messages = messagesSent
        'CalculationPay()
    End Sub

    'Default Constructor
    Friend Sub New()

    End Sub

#End Region

#Region "Class Methods"

    'Calculates the payment.
    Protected Friend Overridable Sub CalculationPay()

        If IsValid Then

            Dim employeeRate As Decimal

            'Declaring payment threshold constants which help clean up the 'if' statment underneath.
            Const PayThresholdSmall As Integer = 250
            Const PayThresholdMedium As Integer = 500
            Const PayThreshholdLarge As Integer = 750
            Const BonusPayStart As Integer = 1200

            'Declaring payment value constants which also help clean up the 'if' statment underneath.
            Const PayValueExtraSmall As Decimal = 0.14D
            Const PayValueSmall As Decimal = 0.17D
            Const PayValueMedium As Decimal = 0.21D
            Const PayValueLarge As Decimal = 0.25D

            'If the user inputs a number less then 250 it sets the employeeRate with the amount that the PayValXS has (which is 0.14)
            If (MessagesSent < PayThresholdSmall) Then
                employeeRate = PayValueExtraSmall
                'If the user inputs a number less then 500 it sets the employeeRate with the amount that the PayValS has (which is 0.17)
            ElseIf (MessagesSent < PayThresholdMedium) Then
                employeeRate = PayValueSmall
                'If the user inputs a number less then 750 it sets the employeeRate with the amount that the PayValM has (which is 0.21)
            ElseIf (MessagesSent < PayThreshholdLarge) Then
                employeeRate = PayValueMedium
                'If the user inputs a number higher then 750 it sets the employeeRate with the amount that the PayValH has (which is 0.25)
            Else
                employeeRate = PayValueLarge
                If (MessagesSent > BonusPayStart) Then
                    RaiseEvent PromotionEarned(Me)
                End If
            End If

            ' Calculates Pay
            WorkerPay = employeeRate * CDec(MessagesSent)

            'Calculates the total amount of employees processed
            TotalEmployeesProcessed = TotalEmployeesProcessed + 1

            'Calculates the total Pay (over all workers)
            TotalCalculatedPay = TotalCalculatedPay + WorkerPay

            'Calculates the average pay
            AverageCalcualtedPay = TotalCalculatedPay / TotalEmployeesProcessed
        End If


    End Sub

    Protected Friend Overridable Sub GetRidOfWorker()
        TotalEmployeesProcessed -= 1
        TotalCalculatedPay -= WorkerPay
        AverageCalcualtedPay = TotalCalculatedPay / TotalEmployeesProcessed
    End Sub

    Friend Shared Sub ResetSummary()
        TotalEmployeesProcessed = 0
        TotalCalculatedPay = 0D
        AverageCalcualtedPay = 0D
    End Sub

    Protected Friend Overridable Function ToString() As String
        Return Me.Name & " - " & Me.Messages.ToString() & " messages - " & Me.WorkersCalculatedPay.ToString("C")
    End Function

#End Region

#Region "Property Procedures"

    'Returns the workerName value (in Get) if all validation (in the Set section) is good 
    Protected Friend Property Name() As String
        Get
            Return WorkerName
        End Get
        Set(ByVal setName As String)

            Const MinimumNameSize As Integer = 2

            'If the user dosn't input a name or inputs a name that is less then 2 letters then a message box will apear.
            If (setName.Length >= MinimumNameSize) Then
                'If what the user inputs is correctly valid then set the setName variable with the workerName variable to get ready for output.
                WorkerName = setName
            Else
                'The messageBox will tell the user to reinput the data.
                Throw New ArgumentOutOfRangeException("Name", "Value entered is not big enough must be at least: " & MinimumNameSize.ToString() & " characters long.")
                IsValid = False
            End If
        End Set
    End Property

    'Returns the workerName value (in Get) if all validation (in the Set section) is good.
    Protected Friend Property Messages() As String
        Get
            Return MessagesSent.ToString()
        End Get
        Set(ByVal setMessages As String)

            Const MinimumMessages As Integer = 1
            Const MaximumMessages As Integer = 3000

            'If the user inputs a letter or symbol then an exception will get caught. But if the input is correct then the data from setMessages will get moved to the messagesSent variable.
            If Integer.TryParse(setMessages, MessagesSent) Then
                'Checks to see if you user enters a negative number. If the user does then an exception will get caught.
                If (MessagesSent < 0) Then
                    'The exception will tell the user to input a positive number
                    Throw New ArgumentException("Negative values are not aloud", "Messages Sent")
                    If (MessagesSent < MinimumMessages) And (MessagesSent > MaximumMessages) Then
                        'The exception will tell the user to reinput the data.
                        Throw New ArgumentOutOfRangeException("Messages Sent", "Value entered is outside of the acceptable range: " & MinimumMessages.ToString() & " - " & MaximumMessages.ToString())
                        IsValid = False
                    End If
                End If
                'If the user inputs a value that is less then 1 or greater then 3000 then an exception will get caught.
            Else
                'The exception will tell the user to not input any letters or symbols
                Throw New ArgumentException("Input of letters, symbols, and decimal values are not allowed.", "Messages Sent")
                IsValid = False
            End If
        End Set
    End Property

    'Only outputs the workerPay variable because there is no validation thats needed for the variable.
    Protected Friend ReadOnly Property WorkersCalculatedPay() As Double
        Get
            Return WorkerPay
        End Get
    End Property

    'Only outputs the totalEmployeesProcessed variable because there is no validation thats needed for the variable.
    Protected Friend Shared ReadOnly Property TotalNumberOfEmployees() As Integer
        Get
            Return TotalEmployeesProcessed
        End Get
    End Property

    'Only outputs the totalMessagesSent variable because there is no validation thats needed for the variable.
    Protected Friend ReadOnly Property AllMessagesSent() As Integer
        Get
            Return TotalMessagesSent
        End Get
    End Property

    'Only outputs the totalCalculatedPay variable because there is no validation thats needed for the variable.
    Protected Friend Shared ReadOnly Property TotalPay() As Double
        Get
            Return TotalCalculatedPay
        End Get
    End Property

    'Only outputs the averageCalcualtedPay variable because there is no validation thats needed for the variable.
    Protected Friend Shared ReadOnly Property AveragePay() As Double
        Get
            Return AverageCalcualtedPay
        End Get
    End Property

    'Only outputs the BonusPayOne variable because there is no validation thats needed for the variable.
    Protected Friend ReadOnly Property BonusPayOneProperty() As Decimal
        Get
            Return BonusPayOne
        End Get
    End Property

    'Only outputs the BonusPayTwo variable because there is no validation thats needed for the variable.
    Protected Friend ReadOnly Property BonusPayTwoProperty() As Decimal
        Get
            Return BonusPayTwo
        End Get
    End Property

#End Region

End Class