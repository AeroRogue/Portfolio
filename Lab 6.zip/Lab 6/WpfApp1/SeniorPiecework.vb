﻿'''''''''''''''''''''''''''''''''''''''''''''''''''''
'Author: Cameron Krueger                            '
'Last Modified Date: December 08, 2017              '
'Descritpion: This is the senior pieceworker class  '
'             that is being used for lab 6.         '
'''''''''''''''''''''''''''''''''''''''''''''''''''''
Friend Class SeniorPiecework
    Inherits Piecework
    Friend Shared Event DemotionMessage(ByVal seniorPieceworkInstance As SeniorPiecework)
    Friend Sub New(ByVal workerName As String, ByVal messagesSent As String)
        MyBase.New()
        MyBase.Name = workerName
        MyBase.Messages = messagesSent
    End Sub
    Friend Sub New()

    End Sub

    Protected Friend Overrides Sub CalculationPay()
        Dim employeeRate As Decimal

        'Declaring payment threshold constants which help clean up the 'if' statment underneath.
        Const PayThresholdSmall As Integer = 250
        Const PayThresholdMedium As Integer = 500
        Const PayThreshholdLarge As Integer = 750

        'Declaring payment value constants which also help clean up the 'if' statment underneath.
        Const PayValueExtraSmall As Decimal = 0.1D
        Const PayValueSmall As Decimal = 0.13D
        Const PayValueMedium As Decimal = 0.16D
        Const PayValueLarge As Decimal = 0.2D

        If (MessagesSent < 300) Then
            RaiseEvent DemotionMessage(Me)
        End If
        'If the user inputs a number less then 250 it sets the employeeRate with the amount that the PayValXS has (which is 0.1)
        If (MessagesSent < PayThresholdSmall) Then
            employeeRate = PayValueExtraSmall
            'If the user inputs a number less then 500 it sets the employeeRate with the amount that the PayValS has (which is 0.13)
        ElseIf (MessagesSent < PayThresholdMedium) Then
            employeeRate = PayValueSmall
            'If the user inputs a number less then 750 it sets the employeeRate with the amount that the PayValM has (which is 0.16)
        ElseIf (MessagesSent < PayThreshholdLarge) Then
            employeeRate = PayValueMedium
            'If the user inputs a number higher then 750 it sets the employeeRate with the amount that the PayValH has (which is 0.2)
        Else
            employeeRate = PayValueLarge
        End If

        ' Calculates Pay
        WorkerPay = employeeRate * CDec(MessagesSent) + 150

        'Calculates the total amount of employees processed
        TotalEmployeesProcessed = TotalEmployeesProcessed + 1

        'Calculates the total Pay (over all workers)
        TotalCalculatedPay = TotalCalculatedPay + WorkerPay

        'Calculates the average pay
        AverageCalcualtedPay = TotalCalculatedPay / TotalEmployeesProcessed
    End Sub

End Class
