﻿'''''''''''''''''''''''''''''''''''''''''''''''''''''
'Author: Cameron Krueger                            '
'Last Modified Date: December 08, 2017              '
'Descritpion: This is Lab 6 for net development.    '
'''''''''''''''''''''''''''''''''''''''''''''''''''''
Imports System.Windows.Threading
Imports System.Data
Imports System.Data.SqlClient
Class PaymentForm

#Region "Class level variables"
    'Creating an object from the Piecework class.
    Private WithEvents PayObject As New Piecework
    Private WithEvents Clock As DispatcherTimer
    Friend payrollList As New List(Of Piecework)
#End Region

#Region "Event Handelers"
    ''' <summary>
    ''' When the user clicks the Clear button. The Payment tab will get set to it's Defaluts.
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ButtonClear_Click(sender As Object, e As RoutedEventArgs) Handles btnClear.Click
        'Calls the SetDefaluts function. Which clears the input and output elements on the form
        Call SetDefaluts()
        'The description label tells the user that the data has been cleared
        lblDesc.Content = "Data Cleared"
    End Sub

    'Everything in this function exicutes when the form loads
    Private Sub FormLoad(sender As Object, e As RoutedEventArgs) Handles Me.Loaded
        'Calls the SetDefaluts function. Which clears the input and output elements on the form
        Call SetDefaluts()
        'Setting up the DispatcherTimer so that the time and date will update while the program is running. 
        Clock = New DispatcherTimer
        Clock.Interval = TimeSpan.FromSeconds(1)
        'Handels the clock.Tick event.
        AddHandler Clock.Tick, AddressOf DispatcherTimer_Tick
        'Starts the timer (clock)
        Clock.Start()
        'The description label welcomes the user
        lblDesc.Content = "Welcome User"
    End Sub

    'Everything in this function exicutes every second while the program is running.
    Private Sub DispatcherTimer_Tick(sender As Object, e As EventArgs) Handles Clock.Tick
        'Puts the current date and time onto the DateTime label.
        lblDateTime.Content = Date.Now.ToString()
    End Sub


    ''' <summary>
    ''' When the user clicks the Calculate button. The events underneath will occur
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    Private Sub ButtonCalculate_Click(sender As Object, e As RoutedEventArgs) Handles btnCalculate.Click

        'Beginning of a Try...Catch block for input 
        Try

            'Links input from the textBoxes (where the user inputs) with the Piecework Class
            If radRegEmp.IsChecked Then
                PayObject = New Piecework()
                AddHandler PayObject.PromotionEarned, AddressOf TestEventCall
            ElseIf radSenEmp.IsChecked Then
                PayObject = New SeniorPiecework()
                AddHandler SeniorPiecework.DemotionMessage, AddressOf FailEventCall
            End If
            PayObject.Name() = txtWorkerNameEntry.Text
            PayObject.Messages() = txtMessagesSent.Text
            PayObject.CalculationPay()
            'Outputs the calculations and Name into labels that are in the Payment form.
            lblNameDisplayed.Content = PayObject.Name()
            lblPayDisplay.Content = PayObject.WorkersCalculatedPay.ToString("C")
            'Me.dgvWorkers.ItemsSource = DBL.Tables.datWorkers.getAllRows
            payrollList.Add(PayObject)
            FillListBox()
            lbxEmployees.Items.Refresh()
            'After the class objects get outputed the Description label updates with a summary of the user's input and the result. 
            lblDesc.Content = PayObject.ToString() '"Worker " + PayObject.Name() + " has been entered with " + PayObject.Messages.ToString() + vbCrLf + "messages and a pay of " + PayObject.WorkersCalculatedPay.ToString("C")

            'Catch any argument that is out of range. It will catch messages inputed higher then 3000 or lower then 1 or a name inputed with less then 3 characters (0-2).
        Catch ex As ArgumentOutOfRangeException
            ' Send a message to the user indicating one of the values entered is outside of the allowable range.
            MessageBox.Show(ex.Message & vbCrLf & "Please Try Again")
            ' Test the paramter name throwing the exception and set the appropriate controls for re-entry of payroll data.
            If ex.ParamName = "Name" Then
                'Name inputed incorrectly
                txtWorkerNameEntry.SelectAll()
                txtWorkerNameEntry.Focus()
                'update the description label to remind the user what to fix for input
                lblDesc.Content = "Error: Please input a name with more than" & vbCrLf & "          two characters."
            ElseIf ex.ParamName = "Messages Sent" Then
                'Messages inputed incorrectly
                txtMessagesSent.SelectAll()
                txtMessagesSent.Focus()
                'update the description label to remind the user what to fix for input
                lblDesc.Content = "Error: Please input a number between 1 and" & vbCrLf & "          3000 in the messages sent text box."
            End If
            'Catches any exeption that gets thrown (which are located in the Piecework class). An exeption gets thrown if the user inputs anything non-numeric, negative, or any decimal amount in the messages textbox.
        Catch ex As ArgumentException
            ' Send a message to the user indicating that they inputed the wrong data type into the MessagesSent textbox.
            MessageBox.Show(ex.Message & vbCrLf & "Please Try Again")
            txtMessagesSent.SelectAll()
            txtMessagesSent.Focus()
            lblDesc.Content = "Error: Please enter a positive, whole number" & vbCrLf & "          in the messages sent text box."
        End Try

    End Sub

    'If the Bonus event gets activated (user input more then 1200 messages) then the code in this method exicutes.
    Private Sub TestEventCall(ByVal workerInstance As Piecework)
        lblWorkerUpdateMessage.Content = "Promotion Earned"
    End Sub

    Private Sub FailEventCall(ByVal workInstance As Piecework)
        lblWorkerUpdateMessage.Content = "You got Demoted"
    End Sub

    Private Sub TextChanged(sender As Object, e As RoutedEventArgs) Handles txtWorkerNameEntry.TextChanged, txtMessagesSent.TextChanged
        lblPayDisplay.Content = "$0.00"
    End Sub

    'When the user changes the tabs the code underneath exicutes.
    Private Sub tbcFormTabs_SelectionChanged(ByVal sender As Object, ByVal e As SelectionChangedEventArgs) Handles tbcFormTabs.SelectionChanged
        If tbiPaymentEntry.IsSelected Then
            'Removes inputs and outputs from this tab whenever a user clicks on this tab
            Call SetDefaluts()
            'Description label tells the user that the Tab selection has been changed to the payment tab.
            lblDesc.Content = "Payment tab selected"
        ElseIf tbiSummaryView.IsSelected Then
            'Updates the labels with data that got calculated in the class
            Call UpdateSummaryInfo()
            'Description label tells the user that the Tab selection has been changed to the summary tab.
            lblDesc.Content = "Summary Tab Chosen"
        ElseIf tbiWorkerDBtab.IsSelected Then
            'Pulls the workers from the database and outputs them to the datagrid
            lbxEmployees.Items.Refresh()
            'Description label tells the user that the Tab selection has been changed to the worker info tab.
            lblDesc.Content = "Workers Info tab Chosen"
        End If

    End Sub

    Private Sub btnDelete_Click(sender As Object, e As RoutedEventArgs) Handles btnDelete.Click
        If lbxEmployees.SelectedIndex < 0 Then
            MessageBox.Show("Please Select Worker")
        Else
            lbxEmployees.Items.Remove(lbxEmployees.SelectedItem)
            PayObject.GetRidOfWorker()
        End If
    End Sub

    Private Sub btnClearList_Click(sender As Object, e As RoutedEventArgs) Handles btnClearList.Click
        lbxEmployees.Items.Clear()
        Call Piecework.ResetSummary()
    End Sub

#End Region

#Region "Functions"
    Private Sub UpdateSummaryInfo()
        'When the form loads it outputs data from the Piecework class.
        lblTotalWorkersDisplay.Content = Piecework.TotalNumberOfEmployees.ToString
        lblTotalPayDisplay.Content = Piecework.TotalPay.ToString("C")
        lblAveragePayDisplay.Content = Piecework.AveragePay.ToString("C")
    End Sub

    'Clears off most elements on the form and is put into this function so that other functions just have to call this function.
    Private Sub SetDefaluts()
        'Clears the textboxes of previous inputs
        txtWorkerNameEntry.Text = ""
        txtMessagesSent.Clear()

        'Clears labels of previous inputs
        lblNameDisplayed.Content = String.Empty
        'lblBonusShowEvent.Content = String.Empty
        lblPayDisplay.Content = "$0.00"
        lblWorkerUpdateMessage.Content = String.Empty

        'deselects the radio buttons
        radRegEmp.IsChecked = True

        'sets the cursor to the Name Entry textbox
        txtWorkerNameEntry.Focus()
    End Sub

    Private Sub FillListBox()
        lbxEmployees.Items.Clear()
        For Each payrollItem As Piecework In payrollList
            lbxEmployees.Items.Add(payrollItem.Name & " " & payrollItem.Messages & " " & payrollItem.WorkersCalculatedPay)
        Next
    End Sub
#End Region

End Class
