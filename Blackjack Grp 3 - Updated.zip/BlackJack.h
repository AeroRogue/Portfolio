/*
Program:
Blackjack.h
Authors:
Jacob Neil, Cameron Krueger, Mavrick Martinek
*/

#include <iostream>
#include <sstream>
class BlackJack
{
	private:
		int chipCount;
		int score;
		//int dealersScore;
	public:
		BlackJack() : chipCount(50), score(0)/*, dealersScore(0)*/ {}
		int AddChips(int amount) {chipCount = chipCount + amount;}
		int RemoveChip(int amount) {chipCount = chipCount - amount;}
		int ScoreChanges(int amount) {score = score + amount;}
		int ScoreRemove(int amount) {score = score - amount;}
		int ScoreReset(){score = 0;}
		int addSurrenderedChips(int amount);
		//int DealerScore(int amount) {dealersScore = amount;}
		int addWinningChips() {chipCount = chipCount + score;}
		int addWinningChipsTest() {chipCount = chipCount * 2;}
		int addSurrenderedChips() 
		{
			score = score / 2;
			chipCount = chipCount + score;
		}
		int GetChip() const {return chipCount;}	
		int GetScore() const {return score;}
		bool IfOver21(bool redo);
		//int GetDealerScore() const {return dealersScore;}
};

int BlackJack::addSurrenderedChips(int amount) 
        {
            amount = amount / 2;
            chipCount = chipCount + amount;
        }
