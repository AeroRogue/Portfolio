/*
StandardDeck.h
Mavrick Martinek, Jacob Neil, Cameron Krueger
Jan 2018
Header file that defines the collection class StandardDeck.h.
*/

#include "StandardPlayingCard.h"
#include <stdexcept>
#include <ctime>
#include <iostream>
#include <algorithm> 
#include <time.h> 
//Class handling the deck/shoe.
class StandardDeck
{
	private:
		int deckSize;
		deque<StandardPlayingCard> hand;
		bool outOfCards;
	public:
		StandardDeck(int size);
		virtual void Initialize(); 
		
		int CardsRemaining() const {return deckSize;}//Returns the amount of cards remaining.
		//friend ostream& operator<< (ostream& out, const StandardDeck& deck);
		//string DisplayHand(deque<StandardPlayingCard>& theDeque);
		
		StandardPlayingCard DrawNextCard();
		StandardPlayingCard DrawRandomCard();
		void Shuffle();
		
		bool isEmpty() {return outOfCards;};
		
	//	~StandardDeck() { cout << "\nDeleted\n"; delete [] hand;} // Destructor
		StandardDeck(const StandardDeck &source); // New copy constructor
		StandardDeck& operator=(const StandardDeck &source); // Assignment operator
		
		void Resize(int newSize);
};

StandardDeck::StandardDeck(int size)
{
	//hand = 0;
	Initialize(); 
}
//Fills the deck with cards.
void StandardDeck::Initialize()
{
	deckSize = 52; //Sets the deckSize
	outOfCards = false;

	for (int k = StandardPlayingCard::MIN_SUIT; k != StandardPlayingCard::MAX_SUIT + 1; ++k)
	{
		for (int i = StandardPlayingCard::MIN_RANK; i != StandardPlayingCard::MAX_RANK + 1; ++i)
		{	
			Rank r_ank = static_cast<Rank>(i);
			Suit s_uit = static_cast<Suit>(k);
			StandardPlayingCard card (r_ank, s_uit);
			hand.push_back(card); 
		}
		
	}
	Shuffle(); //Shuffles deck.
	//For loop used for debugging which displaying each card in deck.
	/*for(int i;i<hand.size();i++)
	{	
		cout << i+1 << " - " << hand[i] << endl;	
	}*/
}

void StandardDeck::Resize(int newSize)
{
	StandardPlayingCard * newDeque = new StandardPlayingCard[newSize]; 
	int elementsToCopy = (deckSize < newSize)? deckSize : newSize; 
	

	for(int i = 0; i < elementsToCopy; i++)
		newDeque[i] = hand[i];

	// Declares the new size. 
	deckSize = newSize;
}
//Function for drawing a card from the shoe.
StandardPlayingCard StandardDeck::DrawNextCard()
{
	if(deckSize <= 0) //Checks if deck is empty.
	{
		//throw out_of_range("Can't draw next card; container empy. ");
		cout << "You ran out of cards" << endl;
		outOfCards = true;
	}
	else
	{
		deckSize -= 1; //Reduces deck size by 1.
		StandardPlayingCard card = hand[0];
		hand.pop_front(); //Removes first card from shoe.
		return card;
	}
}
//Function for drawing random card from shoe.
StandardPlayingCard StandardDeck::DrawRandomCard()
{
	if(deckSize <= 0) //Checks if deck is empty.
	throw out_of_range("Can't draw random card; container empy. ");
	int randNum = rand()%(deckSize); //Initializes random number.
	StandardPlayingCard card = hand[randNum]; //Retrieves random card.
	return card;
}
//Shuffle the whole shoe.
void StandardDeck::Shuffle()
{
	if(deckSize <= 0)
	throw out_of_range("Can't shuffle cards; container empy. ");
	srand (time(0));  //Used for randomization.
	random_shuffle(hand.begin(), hand.end()); //Shoe is shuffled.
}
//Overlaods assignment operator.
StandardDeck& StandardDeck::operator=(const StandardDeck &original)
{	
    for (int i = 0; i < original.CardsRemaining(); i++)
    {
        hand[i] = original.hand[i]; 
    }
    return *this;
} 

/*bool StandardDeck::isEmpty()
{
	if (hand.empty() == true)
	{
		return true;
		cout << "The shoe ran out of cards!" << endl;
	}
	else
	{
		return false;
	}
}*/
/*string DisplayHand(deque<StandardPlayingCard>& theDeque)
{
	// To traverse a deque, you MAY use an iterator or you
	// can use operator[] or .at() like a vector.
	for (int i=0; i<theDeque.size(); ++i) {
        cout << theDeque[i] << endl;
    }
}

ostream& operator<< (ostream& out, const StandardDeck& deck)
{
	out <<  DisplayHand(deck);
	return out;
}*/
