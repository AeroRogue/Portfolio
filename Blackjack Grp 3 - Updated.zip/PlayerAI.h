/*
Program:
PlayerAI.h
Authors:
Jacob Neil, Cameron Krueger, Mavrick Martinek
*/


#include <iostream>
#include <sstream>
#include <string>
#include <deque>
#include <algorithm> 
#include <vector>
#include <fstream>
//#include "dealer.h"
//#include "StandardDeck.h"
//#include "StandardPlayingCard.h"
//#include "BlackJack.h"
//#include "PlayerAI.h"

using namespace std;

class PlayerAI
{
	private:
		int score;
		int ammountOfChips;	
		int randomBet;
		bool endPlaying;
	public:
		PlayerAI(): score(0), ammountOfChips(50){}
		
		//void hit();
		void doubleD();
		void surrender();
		int stand(){endPlaying = false;}
		void SettingUpDealer(){Dealer dealer;}
		void displayScore();
		void aiPlays();
		//void Setup();
		//void makeDecision();
		//void finishedRound();
		//int GetScore() const {return score;}
		int GetChips() const {return ammountOfChips;}
		int GetEndPlaying() const {return endPlaying;}
		//int SetEndPlaying() {endPlaying = true;}
		//int ScoreChanges(int amount) {score = score + amount;}
		//int SetChips(int amount){ammountOfChips = ammountOfChips + amount;}	
		//int SetRandomBet();
		
};

void PlayerAI::aiPlays()
{
	Dealer dealer;
	//SettingUpOtherClassVariables();
	StandardDeck deck(52); //Declare main deck.
	deque<StandardPlayingCard> hand;
	deque<StandardPlayingCard> dealerHand;
	StandardPlayingCard nextCard; //Declare card object to be used for player.
	StandardPlayingCard dealerCard; //Declare dealer card to be withdrawn.
	for (int i = 0; i<2; i++)
	{
		nextCard = deck.DrawNextCard(); //Declare card to be withdrawn.
		hand.push_back(nextCard);
		score += nextCard.getRankValue();	
		dealerCard = deck.DrawNextCard();
		dealerHand.push_back(dealerCard);
		dealer.hit(dealerCard.getRankValue());		
	}
	cout << "how many chips would you like to bet ";
	randomBet = rand() % 50 + 1;
	ammountOfChips -= randomBet;
	cout << "AI has " << ammountOfChips << " chips remaining." << endl;
	endPlaying = true;
	while (endPlaying == true)
	{
		dealerCard = deck.DrawNextCard(); //Dealer draws card in deck
		//cout << nextCard.getRankValue() << endl;
		cout << "AI's cards are " << hand[0] << " and " << hand[1] << " with a score of " << score << endl << "Would you like to Hit, Stand, Double Down, or Surender: ";
		//StandardPlayingCard nextCard;
		if (score <= 8)
		{
			nextCard = deck.DrawNextCard();
			score += nextCard.getRankValue();
			cout << "AI drew a " << nextCard << endl;
			cout << "AI's score is: " << score << endl;
			dealer.makeDecision(dealerCard.getRankValue());
			dealer.displayScores();
			if(score > 21)
			{
				cout << "You hit over 21." << endl;
				endPlaying = false;
				//reinput = true;
			}
			else if(dealer.GetScore() > 21)
			{
				cout << "The dealer score hit over 21." << endl;
				endPlaying = false;
				//reinput = true;
			}
			cout << "AI hits." << endl;
		}
		else if (score == 9)
		{
			if (nextCard.getRankValue() <= 2)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
			else if (nextCard.getRankValue() > 2 && nextCard.getRankValue() < 7)
			{
				if(randomBet < 25)
				{
					cout << "not enought chips to double down";
				}
				else
				{
					ammountOfChips -= randomBet * 2;
					nextCard = deck.DrawNextCard();
					score += nextCard.getRankValue();
					ammountOfChips += score;
					endPlaying = false;
				}
				cout << "AI Double Downs" << endl;
			}
			else if (nextCard.getRankValue() >= 7)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
		}
		else if (score == 10)
		{
			if(nextCard.getRankValue() <= 9 && nextCard.getRankValue() >= 2)
			{
				if(randomBet < 25)
				{
					cout << "not enought chips to double down";
				}
				else
				{
					ammountOfChips -= randomBet * 2;
					nextCard = deck.DrawNextCard();
					score += nextCard.getRankValue();
					ammountOfChips += score;
					endPlaying = false;
				}
				cout << "AI Double Downs" << endl;
			}
			else if(nextCard.getRankValue() == 10 || nextCard.getRankValue() == 1)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
		}
		else if (score == 11)
		{
			if(randomBet < 25)
			{
				cout << "not enought chips to double down";
			}
			else
			{
				ammountOfChips -= randomBet * 2;
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				ammountOfChips += score;
				endPlaying = false;
			}
			cout << "AI Double Downs" << endl;
		}
		else if (score == 12)
		{
			if (nextCard.getRankValue() < 4 && nextCard.getRankValue() > 6)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
			else if (nextCard.getRankValue() > 3 && nextCard.getRankValue() < 7)
			{
			stand();
			cout << "AI stands." << endl;
			}
		}
		else if (score == 13 || score == 14)
		{
			if (nextCard.getRankValue() == 1)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
			else if (nextCard.getRankValue() > 1 && nextCard.getRankValue() < 7)
			{
				stand();
				cout << "AI stands." << endl;
			}
			else if (nextCard.getRankValue() > 6 && nextCard.getRankValue() <= 10)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
		}
		else if (score == 15)
		{
			if (nextCard.getRankValue() == 1)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
			else if (nextCard.getRankValue() > 1 && nextCard.getRankValue() < 7)
			{
				stand();
				cout << "AI stands." << endl;
			}
			else if (nextCard.getRankValue() > 6 && nextCard.getRankValue() < 10)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
			else if (nextCard.getRankValue() == 10)
			{
				surrender();
				cout << "AI surrenders." << endl;
			}
		}
		else if (score == 16)
		{
			if (nextCard.getRankValue() == 1)
			{
				surrender();
				cout << "AI surrenders." << endl;
			}
			else if (nextCard.getRankValue() > 1 && nextCard.getRankValue() < 7)
			{
				stand();
				cout << "AI stands." << endl;
			}
			else if (nextCard.getRankValue() == 7 || nextCard.getRankValue() == 8)
			{
				nextCard = deck.DrawNextCard();
				score += nextCard.getRankValue();
				cout << "AI drew a " << nextCard << endl;
				cout << "AI's score is: " << score << endl;
				dealer.makeDecision(dealerCard.getRankValue());
				dealer.displayScores();
				if(score > 21)
				{
					cout << "You hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				else if(dealer.GetScore() > 21)
				{
					cout << "The dealer score hit over 21." << endl;
					endPlaying = false;
					//reinput = true;
				}
				cout << "AI hits." << endl;
			}
			else if (nextCard.getRankValue() > 8)
			{
				surrender();
				cout << "AI surrenders." << endl;
			}	
		}
		else 
		{
			stand();
			cout << "AI stands." << endl;
		}
	}
	cout << "Finished game with score of: " << score << endl;
	cout << "Dealer finished game with score of: " << dealer.GetScore() << endl;
	if (score > dealer.GetScore() && score < 21)
	{
		cout << "You won!" << endl;
		ammountOfChips += randomBet * 2;
	}
	else if (score < dealer.GetScore() || score > 21)
	{
		cout << "You lost!" << endl;
		//computerAI.RemoveChip(amountToRemove);
	}
	else
	{
		cout << "You tied!" << endl;
		ammountOfChips += randomBet;
	}
	cout << "You finished with " << ammountOfChips << " chips" << endl;
	score = 0;
	dealer.resetScore();
}

void PlayerAI::surrender()
{
	score /= 2;
	ammountOfChips += score;
	endPlaying = false;
}

void PlayerAI::displayScore()
{
	cout << "Player score is " << score << endl;
}

/*int PlayerAI::SetRandomBet()
{
	randomBet = rand() % 50 + 1;
	ammountOfChips -= randomBet;
}

void PlayerAI::finishedRound(){}

void PlayerAI::Setup(){}

void PlayerAI::makeDecision(){}

void PlayerAI::hit()
{
	nextCard = deck.DrawNextCard();
	score += nextCard.getRankValue();
	cout << "AI drew a " << nextCard << endl;
	cout << "AI's score is: " << score << endl;
	dealer.makeDecision(dealerCard.getRankValue());
	dealer.displayScores();
	if(score > 21)
	{
		cout << "You hit over 21." << endl;
		endPlaying = false;
		//reinput = true;
	}
	else if(dealer.GetScore() > 21)
	{
		cout << "The dealer score hit over 21." << endl;
		endPlaying = false;
		//reinput = true;
	}
	//score += ammount;
}
void PlayerAI::doubleD()
{
	if(randomBet < 25)
	{
		cout << "not enought chips to double down";
	}
	else
	{
		ammountOfChips -= randomBet * 2;
		nextCard = deck.DrawNextCard();
		score += nextCard.getRankValue();
		ammountOfChips += score;
		endPlaying = false;
	}
}*/
