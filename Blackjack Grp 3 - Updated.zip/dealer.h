#include <iostream>
#include <sstream>
#include <string>
//#include "StandardPlayingCard.h"
//#include "StandardDeck.h"

using namespace std;
//Class handling dealer.
class Dealer
{
	private: 
		int score;
		int minScore;
		bool stillPlaying;
	public:
		//Constructor
		Dealer(): score(0), minScore(17), stillPlaying(true){}
		
		bool continuePlaying();
		int stand(){;}
		//Accessors
		void displayScores();
		int GetScore() const {return score;}
		//Mutators
		void hit(int ammount);
		void makeDecision(int ammount);
		void setState(bool playing);
		void resetScore() {score = 0; stillPlaying = true;}
	
};

void Dealer::makeDecision(int ammount)
{
	if (score < minScore)
	{
		hit(ammount);
		//Cout used for looking at dealer action.
		//cout << "Dealer hits." << endl;
		stillPlaying = true;
	}
	else if (score > 21)
	{
		cout << "Dealer bust!" << endl;
		stillPlaying = false;
	}
	else
	{
		stillPlaying = false;
		cout << "Dealer stands." << endl;
	}
}

void Dealer::hit(int ammount)
{
	/*nextCard = deck.DrawNextCard();
	score += nextCard.getRankValue();*/	
	score += ammount;	//example	
}
void Dealer::displayScores()
{
	cout << "Dealer score is " << score << endl;
	//cout << "Dealer minscore is " << minScore << endl;
}
void Dealer::setState(bool playing)
{
	stillPlaying = playing;
}
bool Dealer::continuePlaying()
{
	return stillPlaying;
}
/*void Dealer::SetScore(int newScore)
{
	score += newScore;
}*/
/*bool Dealer::IfOver21(bool redo)
{
	redo = true;
	if (score > 21)
	{
		redo = false;	
	}	
}*/
