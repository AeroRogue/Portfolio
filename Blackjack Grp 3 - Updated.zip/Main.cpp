/*
Program: Blackjack 2018
Authors: Jacob Neil, Cameron Krueger, Mavrick Martinek
Date Last Modified: 2018/1/12
Description: Main source file for the Blackjack program.  Users can bet variable amounts of 'chips'
on the outcome of the hand, with a winning against the AI dealer doubling theeir bet.
AI users are also enabled, and all gameplay is sent to a log.
*/

//Inclusions
#include <iostream>
#include <sstream>
#include <string>
#include <deque>
#include <algorithm> 
#include <vector>
#include <fstream>
#include "dealer.h"
#include "StandardDeck.h"
#include "StandardPlayingCard.h"
#include "BlackJack.h"
#include "PlayerAI.h"
using namespace std;
//void DisplayHand(deque<StandardPlayingCard>& theDeque);

//Custom Functions
void PlayGame();
void AIGame(int amountOfAI);

//Primary function
int main()
{
	//AI selection loope
	bool reinput = false;
    while(reinput == false)
    {
    	//User Interaction and input gathering
    	int players;
        string playWithAI;
        cout << "Would you like to play with AI: ";
        cin >> playWithAI;
        //AI Playthrough choice
        if (playWithAI == "Yes" || playWithAI == "yes" || playWithAI == "y")
        {
        	int ai;
	        cout << "How many AI players are at the table (maximum of three): ";
	        cin >> ai;
	        players = 1;
	        if (ai != 0 && ai < 4)
	        {
	            for(int i = 0; i = players; --players)
	            {
	                cout << "There is " << players << " at the table" << endl;
	                PlayGame();
	                AIGame(ai);
	            }
	            reinput = true;
	        }
	        else
	        {
	        	cout << "Please enter a number between 1 and 3" << endl;
	            //reinput = true;
			}
		}
		else if (playWithAI == "No" || playWithAI == "no")
		{
			cout << "How many players are at the table: ";
	        cin >> players;
	        if (players != 0 && players <= 4)
	        {
	        	for(int i = 0; i = players; --players)
	            {
	                cout << "There is " << players << " at the table" << endl;
	                PlayGame();
	            }
	            reinput = true;
			}
			else
			{
				cout << "please enter a number between 1 and 4" << endl;
			}
		}
		else
		{
			cout << "Please enter either yes or no" << endl;
		}
    }
	return 0;
}

//Main Gameplay Function
void PlayGame()
{
	//Start log file output
	ofstream log;
	log.open("GameLog.txt");
	time_t now = time(0);
	char* dt = ctime(&now);
	log << dt;
	//Create ruleset and dealer object
	Dealer dealer;
	BlackJack gameLogic;
	int newChipCount;
	bool reinput = false;
	//ask if user wants to have additional chips
	cout << "You start with 50 chips but if you would like to add more chips input the amount here: ";
	cin >> newChipCount;
	//validate input
	while(!cin)
    {
        cout << "Please enter an integer: ";
        cin.clear();
        cin.ignore();
        cin >> newChipCount;
	}
	gameLogic.AddChips(newChipCount);
	log << "Player starts with " << gameLogic.GetChip() << " chips." << endl;
	deque<StandardPlayingCard> hand;
		while (reinput == false)
		{	
		//check that player is ready for hand/exit the game	
			bool continuePlaying = true;
			string startPlay;
			cout << "Would you like to play: ";
			cin >> startPlay;
			//ensure that the player can afford to play
			if (gameLogic.GetChip() <= 0)
			{
				system ("CLS");
				cout << "You have no chips left to bet with. Please Leave Table" << endl;
				reinput = true;
			}
			else
			{
				if (startPlay == "Yes" || startPlay == "yes" || startPlay == "y")
				{
					//clear prior input
					system ("CLS");
					StandardDeck deck(52); //Declare main deck.
					deque<StandardPlayingCard> dealerHand;
					StandardPlayingCard nextCard; //Declare card object to be used for player.
					StandardPlayingCard dealerCard; //Declare dealer card to be withdrawn.			
					int amountToRemove;
					bool loops = true;
					//comment line below to see full deck for debugging purposes
					system ("CLS");
					//get player bet
					cout << "How many chips would you like to bet? ";
					cin >> amountToRemove;
					while(!cin)//Handles innapropriate input.
				    {
				        cout << "Please enter an integer: ";
				        cin.clear();
				        cin.ignore();
				        cin >> amountToRemove;
					}
					gameLogic.RemoveChip(amountToRemove);
					//update and display remaining player balance
					cout << "You have " << gameLogic.GetChip() << " chips remaining." << endl;
					log << gameLogic.GetChip() << " chips remaining." << endl;
					for (int i = 0; i<2; i++)
					{
						nextCard = deck.DrawNextCard(); //Declare card to be withdrawn.
						hand.push_back(nextCard);
						gameLogic.ScoreChanges(nextCard.getRankValue());
						dealerCard = deck.DrawNextCard();
						dealerHand.push_back(dealerCard);
						dealer.hit(dealerCard.getRankValue());		
					}
					while (loops == true)
					{
						loops = false;
						while (continuePlaying == true)
						{
							string input;
							string cont;
							std::deque<StandardPlayingCard>::iterator it = hand.begin();
							bool hasAce;
							bool blackJack = false;
							cout << "Your cards are - ";
							log << "Player hand contains ";
							for(it; it != hand.end(); advance(it, 1))
							{
								cout << *it << " - ";
								log << *it << " - ";
								//Ace value optimization
								if (it->getRankString() == "Ace")
							    {
							    	hasAce = true;
								}
							    if (hasAce && gameLogic.GetScore() <= 11)
							    { 
							   		 gameLogic.ScoreChanges(10);
								}
								//output blackjack notification for natural 21
								else if (hasAce && gameLogic.GetScore() == 21)
								{
									cout << "BlackJack!" << endl;
									blackJack = true;
								}
								else
								{
									hasAce = false;
								}
							}
							//output player score
							cout << " with a score of " << gameLogic.GetScore() << endl;
							if (blackJack == true)
							{
								cout << "BlackJack!" << endl;
								log << "Player got blackjack!" << endl;
								break;
							}
							//get user choice and do processing based on the choice
							cout << "Would you like to Hit, Stand, Double Down, or Surrender?: ";
							log << " with score of " << gameLogic.GetScore() << endl;	
							cin >> input;
							if (input == "Hit" || input == "hit" || input == "h")
							{
								cout << "Hit inputed" << endl;
								nextCard = deck.DrawNextCard();
								hand.push_back(nextCard);
								gameLogic.ScoreChanges(nextCard.getRankValue());
								cout << "You drew a " << nextCard << endl;
								log << "Hit! Drew a " << nextCard << endl;
							}
							else if (input == "Stand" || input == "stand" || input == "s")
							{
								cout << "Stand inputed" << endl;
								log << "Player stands" << endl;
								//gameLogic.addWinningChips();
								continuePlaying = false;
							}
							else if (input == "Double" || input == "double" || input == "double down" || input == "d")
							{
								cout << "DoubleDown inputed.  You doubled the bet" << endl;
								gameLogic.RemoveChip(amountToRemove * 2);
								nextCard = deck.DrawNextCard(); 
								gameLogic.ScoreChanges(nextCard.getRankValue());
								gameLogic.addWinningChips();
								log  << "User doubles down with score " << gameLogic.GetScore() << " and " << gameLogic.GetChip() << " chips." << endl;
								continuePlaying = false;
							}
							else if (input == "Surender" || input == "surender" || input == "surrender" || input == "Surrender")
							{
								cout << "Surendered inputed" << endl;
								cout << "Player surrenders!" << endl;
								gameLogic.addSurrenderedChips(amountToRemove);
								continuePlaying = false;
							}
							else
							{
								cout << "incorrect input" << endl;
							}
							if (gameLogic.GetScore() == 21 || dealer.GetScore() > 21)
							{
								continuePlaying = false;
							}
							if(gameLogic.GetScore() > 21)
							{
								cout << "You hit over 21. Bust!" << endl;
								log << "You hit over 21.";
								if (hasAce && gameLogic.GetScore() > 21)
								{
									gameLogic.ScoreRemove(10);
								}
								else
								{
									continuePlaying = false;
								}
								//reinput = true;
							}
							
							cout << "Your score is: " << gameLogic.GetScore() << endl; 
							log << "Player score now " << gameLogic.GetScore() << endl;
							
							while(dealer.continuePlaying() == true)
							{
								dealerCard = deck.DrawNextCard(); //Dealer draws card in deck
								dealer.makeDecision(dealerCard.getRankValue());
							}	
							//dealer.displayScores();
						}
						loops == false;
					}
					//end of game score output
					cout << "Finished game with score of: " << gameLogic.GetScore() << endl;
					cout << "Dealer finished game with score of: " << dealer.GetScore() << endl;
				    if (gameLogic.GetScore() == dealer.GetScore() || gameLogic.GetScore() > 21 && dealer.GetScore() > 21)
					{
						cout << "You tied!" << endl;
						gameLogic.AddChips(amountToRemove);
						log << "Player tied!" << endl;
					}
					else if (gameLogic.GetScore() > dealer.GetScore() && gameLogic.GetScore() <= 21 || dealer.GetScore() > 21)
					{
						cout << "You won!" << endl;
						gameLogic.AddChips(amountToRemove * 2);
						log << "Player Won!" << endl;
					}
					else if (gameLogic.GetScore() < dealer.GetScore() || gameLogic.GetScore() > 21)
					{
						cout << "You lost!" << endl;
						gameLogic.RemoveChip(amountToRemove);
						log << "Player lost!" << endl;
					}
					
					cout << "You finished with " << gameLogic.GetChip() << " chips" << endl;
					log << "Player finished game with score of " << gameLogic.GetScore() << " and " << gameLogic.GetChip() << " chips" << endl;
					gameLogic.ScoreReset();
					dealer.resetScore();
					hand.clear();
				}
				else if (startPlay == "No" || startPlay == "no")
				{
					reinput = true;
					cout << "Not Playing? exiting";
				}
				else
				{
					cout << "Please enter Yes or No" << endl;
				}
			}
		}
	log.close();
}
//AI control of gameplay
void AIGame(int amountOfAI)
{
	//bool reinput = false;
	for(int i = 0; i = amountOfAI; --amountOfAI)
	{	
		cout << "There is " << amountOfAI << " at the table" << endl;
		PlayerAI computerAI;
		cout << "Would you like to play: ";
		if (computerAI.GetChips() <= 0)
		{
			system ("CLS");
			cout << "You have no chips left to bet with. Please Leave Table" << endl;
		}
		else
		{
			system ("CLS");
			computerAI.aiPlays();
		}
	}
}
