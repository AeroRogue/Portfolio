<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">
		<h1>Register Vehicle</h1>
		<form method="POST" action="/vehicles">

        	<?php echo e(csrf_field()); ?> 

		  <div class="form-group">
		    <label for="title">Make:</label>
		    <input type="text" class="form-control" id='make' name="make">
		  </div>
          <div class="form-group">
		  	<label>Model:</label>
		  	<input type="text" class="form-control" id='model'  name="model">
		  </div>		 
		  <div class="form-group">
		  	<label>Colour</label>
		  	<input type="text" class="form-control" id='colour'  name="colour">
		  </div>
		  <div class="form-group">
		  	<label>Year</label>
		  	<input type="text" class="form-control" id='year' name="year">
		  </div>
		  <div class="form-group">
		  		<label>Photo of your vehicle</label>
		  		<input type="file" accept=".jpg,.jpeg,.png,.tiff,.pdf,.bmp" id='car_photo' name="car_photo">
		  </div>
		  <div class="form-group">
		  	<button type="submit" class="btn btn-primary">Register</button>
		  </div>
		</form>
	</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>