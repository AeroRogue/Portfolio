<script type="text/javascript" src="http://services.iperfect.net/js/IP_generalLib.js">




<?php $__env->startSection('content'); ?>

    <div class="col-sm-8 blog-main">
		<h1>Create Event</h1>
		<form method="POST" action="/events">

        	<?php echo e(csrf_field()); ?> 

		  <div class="form-group">
		    <label for="title">Name:</label>
		    <input type="text" class="form-control" id='name' name="name">
		  </div>
		  <div class="form-group">
		    <label for="body">Date:</label>
            <input class="IP_calendar"  type="text" id="date" name="date" title="Y-m-d">   
		  </div>
		  <div class="form-group">
		  	<label>Early Price</label>
		  	<input type="text" class="form-control" id='early_cost'  name="early_cost">
		  </div>
		  <div class="form-group">
		  	<label>Regular Price</label>
		  	<input type="text" class="form-control" id='reg_cost' name="reg_cost">
		  </div>
		  <div class="form-group">
		  	<button type="submit" class="btn btn-primary">Create</button>
		  </div>
		</form>
	</div>
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>